random_text = [
    "Cool,I'm on it sakshi",
    "okay sakshi.I'm working on it",
    "Just a second sakshi",
]